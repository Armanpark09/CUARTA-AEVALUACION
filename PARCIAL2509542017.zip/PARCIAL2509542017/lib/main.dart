//La organización Domicilios SV
//provee un sistema que permite a
//otras empresas
//almacenar los sitios Web para sus
//negocios. La organización es de
//reciente creación y de
//momento únicamente tiene
//disponible una a infraestructura
//necesaria para montar servidores de
//implementar una palicacion, idea es
//necesario el se expanda sobre la ZONA OCCIDENTAL

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  GoogleMapController mapController;
  static final LatLng _center = const LatLng(13.903633, -89.497598);
  static final LatLng _center = const LatLng(13.989065, -89.676866);
  final Set<Marker> _markers = {};
  LatLng _currentMapPosition = _center;

  void _onAddMarkerButtonPressed() {
    setState(() {
      _markers.add(Marker(
        markerId: MarkerId(_currentMapPosition.toString()),
        position: _currentMapPosition,
        infoWindow: InfoWindow(
            title: 'SUCURSAL DOMICILIO SV',
            snippet: 'BIENVENIDOS A DOMICILIOSV'),
        icon: BitmapDescriptor.defaultMarker,
      ));
    });
  }

  void _onCameraMove(CameraPosition position) {
    _currentMapPosition = position.target;
  }

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('BIENVENIDOS A SU MAPA GUIA'),
          backgroundColor: Colors.black,
        ),
        body: Stack(
          children: <Widget>[
            GoogleMap(
                onMapCreated: _onMapCreated,
                initialCameraPosition: CameraPosition(
                  target: _center,
                  zoom: 10.0,
                ),
                markers: _markers,
                onCameraMove: _onCameraMove),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Align(
                alignment: Alignment.topRight,
                child: FloatingActionButton(
                  onPressed: _onAddMarkerButtonPressed,
                  materialTapTargetSize: MaterialTapTargetSize.padded,
                  backgroundColor: Colors.blue,
                  child: const Icon(Icons.map, size: 50.0),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
